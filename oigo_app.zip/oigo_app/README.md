# OiGO App

OiGO is a cross-platform app that assists with communication and expression of emotions for people with disabilities. 

## Getting Started

To install flutter to test and run all versions of the app, please refer to the [Flutter Documentation](https://flutter.dev/docs/get-started/install) which has many comprehensive walkthroughs of how to set up your environment with flutter and your IDE of choice.

Once flutter is properly installed, clone the oigo_app repository from Git and 'flutter run' on your platform of choice.
